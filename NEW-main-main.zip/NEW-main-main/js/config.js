// Load environment variables from .env file
const config = {
    NUTRITIONIX_APP_ID: 'bffa389c',
    NUTRITIONIX_APP_KEY: '93aadcb4c2b34a4932bdd69f1568fec7',
    GEMINI_API_KEY: 'AIzaSyAbrWhFv5iihYe1Ay10QPV56T1zHN_7w8Y'
};

export default config; 